let str='aabbcccc'
console.log(str)
function Find(str){
    let arr=str.split('');
    console.log(arr);
}
console.log(str);
Find(str);